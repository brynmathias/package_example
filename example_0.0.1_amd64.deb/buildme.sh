#/bin/sh
fpm -s dir -t deb -n example -v 0.0.1 -C ./

